console.log("inside");

//$("div").click(function(){
 // var color = $(this).css("background-color");
 // $("#result").html( 
   //   "That div is <span style='color:" + color + ";'>" + color + "</span>." );
//});



var allreci = document.querySelector(".allreci");
let text2 = document.createElement("h3");
let text = document.createElement("p");
var pro = document.querySelector(".pro");




$( ".ing" ).html( "<span class='red'><h3>Ingredients:</h3> Pleurotus Eryngii, Pine Nuts, Green Pepper, Honey, Soy Saucy.</span>" );
$( ".pro" ).html( "<span class='red'><h3>Step 1:</h3>    Cut the Pleurotus Eryngii in half lengthwise. Draw a cross knife on the curved side. Boil cut Pleurotus mushrooms for 1 minute, remove and drain.  </span>" );
$( ".pro2" ).html( "<span class='red'><h3>Step 2: </h3>Ground the pine nuts into shreds.</span>" );
$( ".pro3" ).html( "<span class='red'><h3>Step 3: </h3>Heat a put over low heat. Fry the Pleurotus Eryngii on both sides until golden brown</span>" );
$( ".pro4" ).html( "<span class='red'><h3>Step 4: </h3>Mix the soy sauce and honey in a ratio of one to one, and pour into the pan.</span>" );
$( ".pro5" ).html( "<span class='red'><h3>Step 5: </h3>Mix the soy sauce and honey in a ratio of one to one, and pour into the pan.</span>" );
$( ".pro51" ).html( "<span class='red'><h3>Step 6: </h3>Sprinkle with shredded pine nuts and green pepper.</span>" );








$( ".ing2" ).html( "<span class='red'><h3>Ingredients:</h3> Pleurotus Eryngii, Pine Nuts, Green Pepper, Honey, Soy Saucy.</span>" );
$( ".pro6" ).html( "<span class='red'><h3>Step 1:</h3>  Preheat oven to 325° and grease an 8 or 9 springform pan with cooking spray. Make crust: In a large bowl, mix together graham cracker crumbs, melted butter, sugar, and salt until totally combined. (Mixture should resemble wet sand.) Press into bottom and up sides of prepared pan. Set aside.  </span>" );
$( ".pro7" ).html( "<span class='red'><h3>Step 2: </h3> In a large bowl using a hand mixer (or in the bowl of a stand mixer), beat cream cheese and sugar until no lumps remain. Add eggs, one at a time, then stir in vanilla and sour cream. Add flour and salt and beat until just combined. Pour mixture over crust. </span>" );
$( ".pro8" ).html( "<span class='red'><h3>Step 3: </h3>Wrap bottom of pan in aluminum foil and place in a large roasting pan. Pour in enough boiling water to come up halfway in the baking pan.</span>" );
$( ".pro9" ).html( "<span class='red'><h3>Step 4: </h3>Bake until center of cheesecake only slightly jiggles, about 1 hour 30 minutes. Turn off heat, prop open oven door, and let cheesecake cool in oven, 1 hour.</span>" );
$( ".pro10" ).html( "<span class='red'><h3>Step 5: </h3>Remove foil and refrigerate cheesecake until completely chilled, at least 5 hours and up to overnight.</span>" );






$( ".ing3" ).html( "<span class='red'><h3>Ingredients:</h3> crisco baking sticks butter flavor all vegetable shortening,light brown sugar, firmly packed, Milk, pure vanilla extract, egg, all purpose flour, salt, baking soda, semi-sweet chocolate chips</span>" );
$( ".pro12" ).html( "<span class='red'><h3>Step 1:</h3>  Preheat the oven to 375 degrees  </span>" );
$( ".pro13" ).html( "<span class='red'><h3>Step 2: </h3> COMBINE shortening, brown sugar,milk and vanilla in a large bowl. Beat at medium speed of electric mixer until well blended. Beat in egg. combine flour, salt and baking soda. Mix into shortening mixture until just blended. Stir in chocolate chips. </span>" );
$( ".pro14" ).html( "<span class='red'><h3>Step 3: </h3>Drop by rounded measuring tablespoons 3 inches apart onto a Ungreased baking sheet.</span>" );
$( ".pro15" ).html( "<span class='red'><h3>Step 4: </h3>BAKE 8 to 10 minutes for chewy cookies, or 11 to 13 minutes for crisp cookies. Cool 2 minutes on cooling racks</span>" );






















